# import
import pandas as pd
import re
import sys 
import spacy
import neuralcoref

  
# total arguments 
n = len(sys.argv) 

path=sys.argv[1]
file_name=sys.argv[2]
final_folder=sys.argv[3]

df=pd.read_json(path+file_name)


nlp = spacy.load('en')

# Let's try before using the conversion dictionary:
neuralcoref.add_to_pipe(nlp)

c=1
for index, row in df.iterrows():
    txt=row['dialogue']
    txt_list=[]
    
    for i in txt.split("\n"):
        if len(txt) > 5:
            prefix=i.split(":")[0]
            suffix=i.split(":")[1]
            txt_list.append(prefix+ " said " + suffix)
    filtered_txt=" ".join(txt_list)
    filtered_txt=re.sub('[^A-Za-z0-9 .]+', '', filtered_txt) 
    for sent in row['summary'].split(".")[:-1]:
        filtered_txt=filtered_txt+"\n\n@highlight \n\n"+sent
    filtered_txt=str(filtered_txt.encode('utf-8'))
    doc = nlp(filtered_txt)
    filtered_txt=doc._.coref_resolved
    f=open(final_folder+file_name.split(".")[0]+"_"+str(c)+'.story',
           'w',encoding='utf-8')
    f.write(filtered_txt)
    f.close()
    c=c+1

print("Preprocessed the JSON file")



