import os
# import subprocess
# subprocess.call(["ls", "-l"])
jar_path="./stanford/stanford-corenlp-full-2016-10-31/stanford-corenlp-3.7.0.jar"

run_summarizer_cmd_test="python run_summarization.py --mode=eval --data_path=./output/test/finished_files/chunked/test_*  --vocab_path=./vocabulary/vocab --log_root=./ --exp_name=pretrained_model --max_enc_steps=5 --max_dec_steps=2 --coverage=1"

run_summarizer_cmd_decode="python run_summarization.py --mode=decode --data_path=./output/finished_files/chunked/test_*  --vocab_path=./vocabulary/vocab --log_root=./ --exp_name=pretrained_model --max_enc_steps=500 --max_dec_steps=40 --coverage=1"

run_summarizer_cmd_train="python run_summarization.py --mode=train --data_path=./output/train/finished_files/chunked/test_*  --vocab_path=./vocabulary/vocab --log_root=./ --exp_name=pretrained_model --max_enc_steps=50 --max_dec_steps=20 --coverage=1"

tokenize_test_cmd="python make_datafiles.py  ./test_stories/  ./output/test/"

tokenize_train_cmd="python make_datafiles.py  ./train_stories/  ./output/train/"

tokenize_decode_cmd="python make_datafiles.py  ./stories  ./output"

footer="""

@highlight

Soyuz capsule lands hundreds of kilometers off-target

@highlight

Capsule was carrying South Korea's first astronaut

@highlight

Landing is second time Soyuz capsule has gone awry"""

def train():
	# Classpath for standford jar
	os.system("export CLASSPATH="+jar_path)

	# make tokenized data
	os.system(tokenize_train_cmd)

	# Run summarizer
	os.system(run_summarizer_cmd_train)

def test():
	# Classpath for standford jar
	os.system("export CLASSPATH="+jar_path)

	# make tokenized data
	os.system(tokenize_test_cmd)

	# Run summarizer
	os.system(run_summarizer_cmd_test)


def get_summary(input_text):
	"""
	input: text
	purpose: generate summary for given input text using pointer geenrator
	output: summary of given input text
	"""
	# create story file
	file = open("./stories/test1.story", "w") 
	file.write(input_text+footer) 
	file.close() 

	f = open("./output/tokenized_stories_dir/test1.story", "w") 
	f.write(input_text+footer)
	f.close() 

	# Classpath for standford jar
	os.system("export CLASSPATH="+jar_path)

	# make tokenized data
	os.system(tokenize_decode_cmd)

	# Run summarizer
	os.system(run_summarizer_cmd_decode)

	file1 = open("output.summary", "r") 
	out=file1.read() 
	file1.close() 

	return out

if __name__ == '__main__':

	

	import time
	start_time = time.time()
	
	# test()
	
	default_text="""Hi David ! How can AGENT help X today ? Can X tell CLIENT whenmy ext payment is due The policy is paid through the renewal in April , so the next payment will be due on April 26 . The renewal will generate about 30 days prior to this date , so CLIENT will see this toward the end of the month . Is mypayment due on the 26th of april ? Correct , the next payment will be due on April 26 . Thankyou for CLIENT's time AGENT appreciated . Thank CLIENT for chatting with us and for choosing Travelers ! AGENT will be ending our chat session now . CLIENT will then see a link for our Customer Satisfaction Survey . We would love to hear CLIENT's feedback so please take a moment to fill it out and let us know how we are doing . ?"""
	summary_text=get_summary(default_text)

	print("--- %s seconds ---" % (time.time() - start_time))

